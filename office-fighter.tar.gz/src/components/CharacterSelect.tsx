import { useGameStore } from '@/store/gameStore';
import { characters, Character } from '@/data/characters';

function CharacterCard({
  character,
  isSelected,
  onClick,
  disabled,
}: {
  character: Character;
  isSelected: boolean;
  onClick: () => void;
  disabled: boolean;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        width: '160px',
        padding: '15px',
        background: isSelected
          ? `linear-gradient(180deg, ${character.color}33 0%, ${character.color}11 100%)`
          : 'rgba(20, 20, 40, 0.9)',
        border: `3px solid ${isSelected ? character.color : '#4a4a6a'}`,
        borderRadius: '12px',
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.4 : 1,
        transition: 'all 0.2s',
        transform: isSelected ? 'scale(1.05)' : 'scale(1)',
        boxShadow: isSelected ? `0 0 20px ${character.color}66` : 'none',
      }}
    >
      <div style={{ fontSize: '48px', textAlign: 'center', marginBottom: '10px' }}>
        {character.sprite}
      </div>
      <div
        style={{
          fontSize: '14px',
          color: character.color,
          textAlign: 'center',
          marginBottom: '4px',
          fontWeight: 'bold',
        }}
      >
        {character.name}
      </div>
      <div
        style={{
          fontSize: '10px',
          color: '#aaaacc',
          textAlign: 'center',
        }}
      >
        {character.title}
      </div>

      {/* 属性条 */}
      <div style={{ marginTop: '12px', fontSize: '8px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
          <span style={{ color: '#ff4757' }}>HP</span>
          <span>{character.maxHp}</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
          <span style={{ color: '#3498db' }}>MP</span>
          <span>{character.maxMp}</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ color: '#ffd700' }}>攻速</span>
          <span>{character.attackSpeed}</span>
        </div>
      </div>
    </button>
  );
}

function SkillDisplay({ character }: { character: Character }) {
  const skills = [
    { key: 'attack', label: '普攻', color: '#aaaacc' },
    { key: 'skill1', label: '技能1', color: '#3498db' },
    { key: 'skill2', label: '技能2', color: '#9b59b6' },
    { key: 'ultimate', label: '终极技', color: '#ffd700' },
  ];

  return (
    <div
      style={{
        marginTop: '20px',
        padding: '15px',
        background: 'rgba(20, 20, 40, 0.9)',
        borderRadius: '8px',
        border: '2px solid #4a4a6a',
      }}
    >
      <div style={{ fontSize: '10px', color: '#aaaacc', marginBottom: '10px' }}>技能预览</div>
      {skills.map((s) => {
        const skill = character.skills[s.key as keyof typeof character.skills];
        return (
          <div
            key={s.key}
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '8px',
              padding: '8px',
              background: `${s.color}11`,
              borderRadius: '4px',
              borderLeft: `3px solid ${s.color}`,
            }}
          >
            <div>
              <div style={{ fontSize: '10px', color: s.color }}>{skill.name}</div>
              <div style={{ fontSize: '8px', color: '#666688' }}>{skill.description}</div>
            </div>
            <div style={{ fontSize: '8px', color: '#aaaacc', textAlign: 'right' }}>
              <div>伤害: {skill.damage || '-'}</div>
              <div>耗蓝: {skill.mpCost}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

export default function CharacterSelect() {
  const { setScreen, setPlayer1Character, setPlayer2Character, player1Character, player2Character, selectPhase, initBattle } =
    useGameStore();

  const handleSelect = (char: Character) => {
    if (selectPhase === 'p1') {
      setPlayer1Character(char);
    } else {
      setPlayer2Character(char);
    }
  };

  const canConfirm = player1Character && player2Character;

  return (
    <div
      style={{
        width: '100vw',
        height: '100vh',
        background: 'linear-gradient(180deg, #0f0f23 0%, #1a1a3e 50%, #0f0f23 100%)',
        padding: '20px',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      {/* 顶部标题 */}
      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <h1 style={{ fontSize: '24px', color: '#ffd700', textShadow: '0 0 10px #ffd700' }}>
          选择你的战士
        </h1>
        <p style={{ fontSize: '12px', color: '#aaaacc', marginTop: '8px' }}>
          {selectPhase === 'p1' ? '👉 玩家1 请选择角色' : '👉 玩家2 请选择角色'}
        </p>
      </div>

      {/* 已选角色预览 */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'center',
          gap: '40px',
          marginBottom: '20px',
        }}
      >
        <div
          style={{
            padding: '15px 30px',
            background: player1Character
              ? `linear-gradient(180deg, ${player1Character.color}33 0%, ${player1Character.color}11 100%)`
              : 'rgba(20, 20, 40, 0.9)',
            borderRadius: '12px',
            border: `3px solid ${player1Character ? player1Character.color : '#4a4a6a'}`,
            textAlign: 'center',
            minWidth: '150px',
          }}
        >
          <div style={{ fontSize: '12px', color: '#aaaacc', marginBottom: '8px' }}>玩家1</div>
          <div style={{ fontSize: '36px' }}>{player1Character?.sprite || '❓'}</div>
          <div style={{ fontSize: '12px', color: player1Character?.color || '#666' }}>
            {player1Character?.name || '未选择'}
          </div>
        </div>

        <div
          style={{
            fontSize: '48px',
            display: 'flex',
            alignItems: 'center',
            color: '#ffd700',
          }}
        >
          VS
        </div>

        <div
          style={{
            padding: '15px 30px',
            background: player2Character
              ? `linear-gradient(180deg, ${player2Character.color}33 0%, ${player2Character.color}11 100%)`
              : 'rgba(20, 20, 40, 0.9)',
            borderRadius: '12px',
            border: `3px solid ${player2Character ? player2Character.color : '#4a4a6a'}`,
            textAlign: 'center',
            minWidth: '150px',
          }}
        >
          <div style={{ fontSize: '12px', color: '#aaaacc', marginBottom: '8px' }}>玩家2</div>
          <div style={{ fontSize: '36px' }}>{player2Character?.sprite || '❓'}</div>
          <div style={{ fontSize: '12px', color: player2Character?.color || '#666' }}>
            {player2Character?.name || '未选择'}
          </div>
        </div>
      </div>

      {/* 角色列表 */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'center',
          gap: '15px',
          flexWrap: 'wrap',
          flex: 1,
          overflowY: 'auto',
        }}
      >
        {characters.map((char) => (
          <CharacterCard
            key={char.id}
            character={char}
            isSelected={
              (selectPhase === 'p1' && player1Character?.id === char.id) ||
              (selectPhase === 'p2' && player2Character?.id === char.id)
            }
            onClick={() => handleSelect(char)}
            disabled={selectPhase === 'p2' && player1Character?.id === char.id}
          />
        ))}
      </div>

      {/* 技能预览 */}
        {selectPhase === 'p1' && player1Character && (
          <div style={{ maxWidth: '400px', margin: '0 auto', width: '100%' }}>
            <SkillDisplay character={player1Character} />
          </div>
        )}
        {selectPhase === 'p2' && player2Character && (
          <div style={{ maxWidth: '400px', margin: '0 auto', width: '100%' }}>
            <SkillDisplay character={player2Character} />
          </div>
        )}

      {/* 底部按钮 */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'center',
          gap: '20px',
          marginTop: '20px',
        }}
      >
        <button
          onClick={() => setScreen('title')}
          style={{
            padding: '15px 30px',
            fontSize: '14px',
            fontFamily: 'inherit',
            background: 'rgba(60, 60, 80, 0.8)',
            border: '2px solid #4a4a6a',
            borderRadius: '8px',
            color: '#aaaacc',
            cursor: 'pointer',
          }}
        >
          返回
        </button>

        {selectPhase === 'p1' && player1Character && (
          <button
            onClick={() => useGameStore.setState({ selectPhase: 'p2' })}
            style={{
              padding: '15px 30px',
              fontSize: '14px',
              fontFamily: 'inherit',
              background: 'linear-gradient(180deg, #4CAF50 0%, #2E7D32 100%)',
              border: '2px solid #66BB6A',
              borderRadius: '8px',
              color: '#fff',
              cursor: 'pointer',
            }}
          >
            玩家2选择
          </button>
        )}

        {selectPhase === 'p2' && canConfirm && (
          <button
            onClick={initBattle}
            className="animate-pulse"
            style={{
              padding: '15px 40px',
              fontSize: '16px',
              fontFamily: 'inherit',
              background: 'linear-gradient(180deg, #ff4757 0%, #c0392b 100%)',
              border: '3px solid #ff6b7a',
              borderRadius: '8px',
              color: '#fff',
              cursor: 'pointer',
              boxShadow: '0 0 20px rgba(255, 71, 87, 0.5)',
            }}
          >
            开始战斗!
          </button>
        )}

        {selectPhase === 'p2' && !canConfirm && (
          <div style={{ padding: '15px 30px', color: '#ff4757', fontSize: '12px' }}>
            等待玩家2选择角色...
          </div>
        )}
      </div>
    </div>
  );
}
