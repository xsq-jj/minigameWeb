import { useGameStore } from '@/store/gameStore';

export default function TitleScreen() {
  const setScreen = useGameStore((s) => s.setScreen);

  return (
    <div
      style={{
        width: '100vw',
        height: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'linear-gradient(180deg, #0f0f23 0%, #1a1a3e 50%, #0f0f23 100%)',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* 装饰性背景元素 */}
      <div
        style={{
          position: 'absolute',
          top: '10%',
          left: '10%',
          fontSize: '48px',
          opacity: 0.1,
          animation: 'float 3s ease-in-out infinite',
        }}
      >
        👨‍💼
      </div>
      <div
        style={{
          position: 'absolute',
          top: '20%',
          right: '15%',
          fontSize: '36px',
          opacity: 0.1,
          animation: 'float 4s ease-in-out infinite 0.5s',
        }}
      >
        👩‍💻
      </div>
      <div
        style={{
          position: 'absolute',
          bottom: '20%',
          left: '20%',
          fontSize: '42px',
          opacity: 0.1,
          animation: 'float 3.5s ease-in-out infinite 1s',
        }}
      >
        🧔
      </div>
      <div
        style={{
          position: 'absolute',
          bottom: '15%',
          right: '10%',
          fontSize: '38px',
          opacity: 0.1,
          animation: 'float 4.5s ease-in-out infinite 0.3s',
        }}
      >
        👩‍🔧
      </div>

      {/* 主标题 */}
      <div
        className="animate-slide-up"
        style={{
          textAlign: 'center',
          marginBottom: '60px',
        }}
      >
        <h1
          style={{
            fontSize: 'clamp(24px, 5vw, 48px)',
            color: '#ffd700',
            textShadow: `
              0 0 10px #ffd700,
              0 0 20px #ffd700,
              0 0 40px #ff8c00,
              4px 4px 0 #1a1a2e
            `,
            marginBottom: '20px',
            letterSpacing: '4px',
          }}
        >
          办公室格斗大会
        </h1>
        <p
          style={{
            fontSize: 'clamp(10px, 2vw, 16px)',
            color: '#aaaacc',
            letterSpacing: '2px',
          }}
        >
          OFFICE FIGHTING CHAMPIONSHIP
        </p>
      </div>

      {/* 拳头图标 */}
      <div
        className="animate-float"
        style={{
          fontSize: '80px',
          marginBottom: '40px',
          filter: 'drop-shadow(0 0 20px #ff4757)',
        }}
      >
        👊
      </div>

      {/* 开始按钮 */}
      <button
        onClick={() => setScreen('select')}
        className="animate-pulse"
        style={{
          padding: '20px 60px',
          fontSize: 'clamp(12px, 2.5vw, 20px)',
          fontFamily: 'inherit',
          background: 'linear-gradient(180deg, #ff4757 0%, #c0392b 100%)',
          border: '4px solid #ff6b7a',
          borderRadius: '8px',
          color: '#fff',
          cursor: 'pointer',
          textShadow: '2px 2px 0 #1a1a2e',
          boxShadow: '0 6px 0 #8b0000, 0 8px 20px rgba(255, 71, 87, 0.5)',
          transition: 'all 0.1s',
        }}
        onMouseOver={(e) => {
          e.currentTarget.style.transform = 'translateY(-2px)';
          e.currentTarget.style.boxShadow = '0 8px 0 #8b0000, 0 12px 30px rgba(255, 71, 87, 0.7)';
        }}
        onMouseOut={(e) => {
          e.currentTarget.style.transform = 'translateY(0)';
          e.currentTarget.style.boxShadow = '0 6px 0 #8b0000, 0 8px 20px rgba(255, 71, 87, 0.5)';
        }}
        onMouseDown={(e) => {
          e.currentTarget.style.transform = 'translateY(4px)';
          e.currentTarget.style.boxShadow = '0 2px 0 #8b0000, 0 4px 10px rgba(255, 71, 87, 0.5)';
        }}
        onMouseUp={(e) => {
          e.currentTarget.style.transform = 'translateY(-2px)';
          e.currentTarget.style.boxShadow = '0 8px 0 #8b0000, 0 12px 30px rgba(255, 71, 87, 0.7)';
        }}
      >
        开始战斗
      </button>

      {/* 底部说明 */}
      <div
        style={{
          position: 'absolute',
          bottom: '30px',
          fontSize: '10px',
          color: '#4a4a6a',
          textAlign: 'center',
          lineHeight: '1.8',
        }}
      >
        <p>双人对战 · 选择角色 · 释放技能</p>
        <p style={{ marginTop: '8px', color: '#3a3a5a' }}>
          玩家1: WASD移动 J普通攻击 K技能1 L技能2 I终极技
        </p>
        <p style={{ color: '#3a3a5a' }}>
          玩家2: 方向键移动 1普通攻击 2技能1 3技能2 0终极技
        </p>
      </div>
    </div>
  );
}
