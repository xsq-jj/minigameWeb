import { useGameStore } from '@/store/gameStore';
import TitleScreen from '@/components/TitleScreen';
import CharacterSelect from '@/components/CharacterSelect';
import BattleArena from '@/components/BattleArena';
import VictoryScreen from '@/components/VictoryScreen';

export default function App() {
  const screen = useGameStore((s) => s.screen);

  return (
    <div style={{ width: '100vw', height: '100vh' }}>
      {screen === 'title' && <TitleScreen />}
      {screen === 'select' && <CharacterSelect />}
      {screen === 'battle' && <BattleArena />}
      {screen === 'victory' && <VictoryScreen />}
    </div>
  );
}
